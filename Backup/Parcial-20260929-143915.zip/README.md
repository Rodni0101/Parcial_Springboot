# SpringStore: apuntes para estudiar el proyecto

Este README explica, con palabras sencillas, cómo está organizado el proyecto y qué se agregó para registrar productos con imágenes y editarlos. La aplicación usa Spring Boot, Java, Thymeleaf y MySQL.

## Tecnologías

- **Java 21 y Spring Boot:** ejecutan la aplicación web.
- **Spring MVC:** recibe las solicitudes del navegador y selecciona qué vista mostrar.
- **Thymeleaf:** inserta los datos de Java en las páginas HTML.
- **Spring Data JPA e Hibernate:** guardan y consultan productos en MySQL.
- **MySQL:** conserva los datos de los productos.
- **Maven:** compila el proyecto y ejecuta las pruebas.

## Iniciar la aplicación

1. Comprueba que MySQL esté iniciado y que exista la base de datos `parcial_springboot`.
2. Revisa `src/main/resources/application.properties`. La URL, el usuario y la contraseña deben corresponder a tu instalación local. No compartas ni publiques la contraseña.
3. Desde una terminal en la carpeta del proyecto, ejecuta:

   ```bash
   ./mvnw spring-boot:run
   ```

4. Abre <http://localhost:8080>.

Con `spring.jpa.hibernate.ddl-auto=update`, Hibernate actualiza la estructura de la tabla `productos` según el modelo `Producto`. Por eso, al agregar el campo `imagen` al modelo, no fue necesario crear manualmente una columna `BLOB`: la base guarda el nombre de la imagen como texto.

## Carpetas importantes

```text
src/main/java/com/example/Parcial/
├── config/
│   └── WebConfig.java
├── controlador/
│   └── controller.java
├── model/
│   └── Producto.java
├── repository/
│   └── ProductoRepository.java
└── service/
    └── ProductoImageStorage.java

src/main/resources/
├── static/
│   └── css/
├── templates/
│   ├── crear.html
│   ├── editar.html
│   └── inicio.html
└── application.properties

src/test/java/com/example/Parcial/
└── service/
    └── ProductoImageStorageTest.java

uploads/productos/   Imágenes guardadas en el equipo donde corre la aplicación
```

También hay dos scripts de interfaz en `src/main/resources/static/js/`: `theme-toggle.js` cambia y recuerda el tema, mientras `hero-parallax.js` mueve suavemente los elementos decorativos del encabezado.

- **`model/Producto.java`:** define los campos de cada producto.
- **`repository/ProductoRepository.java`:** ofrece las operaciones de persistencia de Spring Data JPA.
- **`controlador/controller.java`:** recibe las rutas web, consulta o guarda productos y devuelve vistas o redirecciones.
- **`service/ProductoImageStorage.java`:** valida las imágenes y las guarda en el disco.
- **`config/WebConfig.java`:** configura cómo se entregan esos archivos al navegador.
- **`templates/`:** contiene las páginas HTML de Thymeleaf.
- **`static/css/`:** contiene los estilos.
- **`application.properties`:** configura MySQL, el límite de carga y la carpeta de imágenes.

## Prioridad: cómo viaja una imagen desde el formulario hasta la card

La aplicación **no guarda los bytes de la imagen en MySQL**. Guarda el archivo en `uploads/productos/` y almacena en la base el nombre generado, por ejemplo `8f1...a2.png`. Así se relaciona la imagen con el producto sin convertir la columna de la base en un campo binario grande.

### 1. El formulario de creación

En `crear.html`, el formulario tiene:

```html
enctype="multipart/form-data"
```

Este atributo permite enviar archivos junto con los demás campos. El selector se llama `archivoImagen`:

```html
<input type="file" id="archivoImagen" name="archivoImagen"
       accept="image/jpeg,image/png,image/gif" required>
```

El nombre `archivoImagen` es importante: evita confundir el archivo con la propiedad `imagen` del objeto `Producto`, que contiene texto. El formulario también pide nombre, categoría, precio, cantidad y descripción.

### 2. El controlador recibe los datos

En `controller.java`, el método `guardarProducto` procesa el envío `POST /Crear`:

```java
@PostMapping("/Crear")
public String guardarProducto(
        @ModelAttribute Producto producto,
        @RequestParam("archivoImagen") MultipartFile imagen,
        RedirectAttributes redirectAttributes) throws IOException {
    try {
        producto.setImagen(imageStorage.save(imagen));
    } catch (IllegalArgumentException exception) {
        redirectAttributes.addFlashAttribute("error", exception.getMessage());
        return "redirect:/Crear";
    }
    productoRepository.save(producto);
    return "redirect:/";
}
```

Qué hace cada parte:

- **`@PostMapping("/Crear")`:** asocia este método con el envío del formulario a `/Crear`.
- **`@ModelAttribute Producto producto`:** Spring reúne los campos de texto y números del formulario en un objeto `Producto`.
- **`@RequestParam("archivoImagen") MultipartFile imagen`:** recibe el archivo seleccionado. El texto entre comillas debe coincidir con el `name` del selector HTML.
- **`imageStorage.save(imagen)`:** solicita al servicio validar y guardar el archivo. El método devuelve el nombre único del archivo.
- **`producto.setImagen(...)`:** coloca ese nombre en el producto; ese texto es lo que JPA almacenará en MySQL.
- **`catch (IllegalArgumentException ...)`:** captura errores esperados de validación, comunica el mensaje al formulario y vuelve a `/Crear`. `RedirectAttributes` conserva ese mensaje durante la redirección.
- **`productoRepository.save(producto)`:** persiste el producto y el nombre de la imagen.
- **`return "redirect:/"`:** pide al navegador volver al catálogo.
- **`throws IOException`:** permite que errores de lectura o escritura del archivo se propaguen; no son errores de validación y este método no los oculta.

### 3. El servicio valida y guarda el archivo

`ProductoImageStorage` es el ayudante encargado del archivo, no de guardar el producto en MySQL. Su método `save(MultipartFile image)` trabaja en este orden:

1. Rechaza un archivo vacío.
2. Comprueba que su tamaño no supere **5 MB**. Este límite es el peso del archivo.
3. Llama a `getImageExtension` para leer el contenido real y aceptar solo JPG, PNG o GIF; no se fía únicamente del nombre ni del `Content-Type` que envía el navegador.
4. Comprueba también que la imagen no supere **40 millones de píxeles**. Esto limita sus dimensiones, que es diferente del peso en MB.
5. Crea `uploads/productos/` si todavía no existe.
6. Genera un nombre basado en UUID para evitar colisiones y usa la extensión verificada.
7. Copia el archivo a esa carpeta y devuelve el nombre.

Otros métodos de `ProductoImageStorage`:

- **Constructor:** toma `app.upload.dir` de la configuración; si no está definida, usa `uploads/productos`. Convierte el directorio a una ruta absoluta normalizada.
- **`getUploadDirectory()`:** entrega la ruta a `WebConfig`.
- **`delete(String filename)`:** elimina un archivo de esa carpeta y verifica que la ruta no intente salir del directorio. Está disponible como ayuda para futuras eliminaciones; el flujo actual de edición no la usa.
- **`getImageExtension(MultipartFile image)`:** método privado que detecta el formato real con `ImageIO`, comprueba las dimensiones y devuelve `jpg`, `png` o `gif`. Lanza un error entendible si el archivo no corresponde a una imagen permitida.

`@Service` le indica a Spring que cree esta clase como un componente reutilizable. El controlador la recibe en su constructor; esto es inyección de dependencias.

### 4. Spring sirve el archivo al navegador

`WebConfig` implementa `WebMvcConfigurer`. Su método `addResourceHandlers` relaciona la dirección web `/uploads/productos/**` con el directorio local `uploads/productos/`. De esta forma, el navegador puede pedir el archivo por HTTP. El servicio guarda el archivo; `WebConfig` no lo guarda ni lo envía directamente a una vista.

### 5. La card presenta la imagen

En `inicio.html`, Thymeleaf recorre los productos con `th:each`. Si `producto.imagen` tiene un nombre, construye la dirección `/uploads/productos/{nombre}` y muestra un `<img>`. Si el campo es `null`, muestra el placeholder “Imagen próximamente”. El estilo `.product-image` en `inicio.css` ajusta la imagen al espacio de la card con `object-fit: cover`.

### 6. Configuración de carga y archivos locales

En `application.properties`:

```properties
spring.servlet.multipart.max-file-size=5MB
spring.servlet.multipart.max-request-size=6MB
app.upload.dir=uploads/productos
```

Spring impone los límites HTTP de carga; el servicio también verifica el peso. `uploads/productos/` está en `.gitignore`: Git no incluye los archivos subidos. Si el proyecto se copia o despliega en otro servidor, también se deben copiar los archivos o configurar almacenamiento persistente.

## Prioridad: editar productos

### Abrir la pantalla

La card enlaza a `/Editar/{id}`, donde `{id}` se reemplaza por el identificador del producto. En `controller.java`, `Editar_Producto` busca el producto con `findById(id).orElseThrow()`, lo agrega al modelo de Thymeleaf con la clave `producto` y muestra `editar.html`.

### El formulario de edición

`editar.html` usa `th:object="${producto}"` y campos `th:field="*{...}"` para rellenar el formulario con los datos actuales. Muestra también la imagen actual cuando existe. El formulario tiene `enctype="multipart/form-data"` para poder enviar opcionalmente una imagen nueva.

El método `actualizarProducto` atiende `POST /Editar/{id}`:

1. Recibe el ID de la ruta, los campos del formulario y, si se eligió uno, el archivo `archivoImagen`.
2. Vuelve a buscar el producto existente en la base de datos.
3. Copia al producto existente los campos editables. Así se conserva el ID y también la imagen existente si no se sube una nueva.
4. Si se envió un archivo, llama al servicio para validarlo y guardarlo; si la validación falla, muestra el mensaje en la vista de edición.
5. Guarda los cambios con `productoRepository.save(producto)` y redirige al inicio.

La imagen nueva reemplaza el nombre guardado en el producto; el archivo anterior no se elimina automáticamente todavía.

## Eliminar un producto

Cada card incluye un formulario con un botón **Eliminar producto**. El formulario envía por `POST` el ID del producto a `/Eliminar/{id}` y pide confirmación en el navegador. El método `eliminarProducto` busca el producto con `findById`, lo elimina de MySQL con `delete` y después pide a `ProductoImageStorage.delete` borrar su imagen local, si tiene. Finalmente redirige al catálogo. Si el producto no existe, `orElseThrow()` informa el error en lugar de fingir que se eliminó.

## Otras funciones del controlador

- **`index(Model model)`:** consulta todos los productos con `findAll()`, los pone en el modelo bajo la clave `productos` y muestra `inicio.html`.
- **`Crear_Producto(Model model)`:** crea un objeto `Producto` vacío, lo pone en el modelo y muestra `crear.html`.
- **`Editar_Producto(Integer id, Model model)`:** busca el registro que se va a editar y presenta `editar.html`.
- **`guardarProducto(...)`:** procesa el alta y la imagen, como se explicó arriba.
- **`actualizarProducto(...)`:** procesa los cambios y permite reemplazar la imagen opcionalmente.
- **`eliminarProducto(id)`:** elimina el producto y su archivo de imagen asociado.
- **Constructor del controlador:** recibe el repositorio y el servicio para poder utilizarlos.

## Modelo y repositorio

`Producto.java` define `id`, `nombre`, `categoria`, `precio`, `cantidadDisponible`, `descripcion` e `imagen`. `@Entity` y `@Table(name = "productos")` indican que JPA debe guardar objetos de esta clase en la tabla `productos`. `@Id` identifica la llave primaria; `@GeneratedValue` permite que la base genere el ID. `imagen` es un `String` con el nombre del archivo, limitado a 255 caracteres mediante `@Column(length = 255)`.

`ProductoRepository` extiende `JpaRepository<Producto, Integer>`; por eso Spring genera las operaciones comunes:

- `findAll()`: lista productos.
- `findById(id)`: busca uno por ID y devuelve un `Optional`.
- `save(producto)`: crea o actualiza.
- `deleteById(id)`: elimina un registro de la base.

## Productos de ejemplo agregados

Se agregaron a la base `parcial_springboot` seis productos tecnológicos con descripciones, precios en pesos colombianos (COP), inventario e imágenes ilustrativas:

| Nombre | Categoría | Precio (COP) | Cantidad | Descripción | Imagen local |
|---|---|---:|---:|---|---|
| Portátil Lenovo IdeaPad Slim 3 | Computadores | 2.499.900 | 5 | Portátil para estudio y trabajo diario, con pantalla amplia, almacenamiento SSD y diseño liviano. Imagen ilustrativa. | `laptop-unsplash.jpg` |
| Samsung Galaxy A56 | Celulares | 1.899.900 | 10 | Teléfono inteligente con pantalla de alta definición, varias cámaras y batería para acompañar el uso durante el día. Imagen ilustrativa. | `smartphone-unsplash.jpg` |
| Teclado mecánico gamer | Accesorios | 180.000 | 8 | Teclado mecánico compacto con teclas de respuesta rápida e iluminación para jugar o trabajar. Imagen ilustrativa. | `keyboard-unsplash.jpg` |
| Mouse inalámbrico ergonómico | Accesorios | 85.000 | 20 | Mouse inalámbrico de diseño ergonómico para navegación y productividad. Imagen ilustrativa. | `mouse-unsplash.jpg` |
| Monitor LG 24 pulgadas | Monitores | 650.000 | 6 | Monitor de 24 pulgadas para estudio, oficina y entretenimiento, con imagen nítida y diseño de bisel delgado. Imagen ilustrativa. | `monitor-unsplash.jpg` |
| Parlante Bluetooth portátil | Audio | 219.900 | 14 | Parlante portátil con conexión Bluetooth para escuchar música en casa o llevar a reuniones. Imagen ilustrativa. | `speaker-unsplash.jpg` |

Las fotos se descargaron como imágenes JPG ilustrativas desde Unsplash y están guardadas en `uploads/productos/`. Fueron preparadas a 700 píxeles de ancho o alto y pesan menos de 5 MB. Unsplash permite el uso de estas imágenes conforme a su [licencia](https://unsplash.com/license); no se deben interpretar como fotografías oficiales de los productos o fabricantes.

Fuentes directas de las imágenes:

- Portátil: <https://images.unsplash.com/photo-1496181133206-80ce9b88a853>
- Celular: <https://images.unsplash.com/photo-1511707171634-5f897ff02aa9>
- Teclado: <https://images.unsplash.com/photo-1587829741301-dc798b83add3>
- Mouse: <https://images.unsplash.com/photo-1527814050087-3793815479db>
- Monitor: <https://images.unsplash.com/photo-1527443224154-c4a3942d3acf>
- Parlante: <https://images.unsplash.com/photo-1608043152269-423dbba4e7e1>

**Importante:** `uploads/productos/` está ignorada por Git, así que los archivos descargados existen en esta copia local pero no se incluirán al subir el código a GitHub. Para ver las imágenes en otro equipo, hay que copiar esa carpeta junto con el proyecto. En MySQL cada producto guarda el nombre local que aparece en la tabla anterior.

## Tema claro y oscuro, logo y encabezado

La página de inicio usa el tema claro como presentación inicial. El botón **Tema oscuro** alterna a una paleta verde más profunda, inspirada en los tonos de Spring Boot. Al elegir un tema, `theme-toggle.js` cambia el atributo `data-theme` del elemento `<html>` y guarda la elección en `localStorage`; cuando se vuelve a abrir el inicio en ese navegador, recupera la preferencia. `inicio.css` contiene las reglas de ambos temas. El logo Spring Boot del favicon se reutiliza junto al nombre SpringStore.

El arte del encabezado (`.hero-art` en `inicio.html`) representa el stack tecnológico como tarjetas flotantes de Spring Boot, Java y MySQL. Sus estilos 3D, órbitas, sombras y animaciones están en `inicio.css`. `hero-parallax.js` calcula cuánto se mueve el puntero dentro del arte y ajusta pequeñas variables CSS para crear profundidad; al salir el puntero, restablece la posición. La animación respeta la preferencia del sistema para reducir movimiento.

Los cuadros de Java y MySQL en esa ilustración son iconos decorativos creados con texto y CSS, no logotipos oficiales de esas marcas. El logo de Spring Boot sí se reutiliza desde el archivo `static/favicon.svg`.

## Operaciones que Spring Data JPA ya proporciona

No fue necesario escribir sentencias SQL para las operaciones habituales del inventario porque `ProductoRepository` extiende `JpaRepository<Producto, Integer>`. Spring Data JPA ya proporciona métodos como:

| Método JPA | Uso en este proyecto |
|---|---|
| `findAll()` | Mostrar todos los productos en la página de inicio. |
| `findById(id)` | Buscar el producto que se va a editar o eliminar. |
| `save(producto)` | Insertar un producto nuevo o guardar cambios a uno existente. |
| `delete(producto)` | Eliminar el producto ya encontrado por ID. |

El ID es `Integer`, por eso el repositorio se declara como `JpaRepository<Producto, Integer>`. Hibernate traduce las llamadas a estos métodos en las consultas SQL correspondientes. Se puede escribir SQL directamente para tareas puntuales o datos iniciales, pero no hace falta repetirlo para las operaciones CRUD comunes.

## Función de las pruebas de imagen

`ProductoImageStorageTest` contiene dos pruebas unitarias:

1. Crea un PNG pequeño en memoria, lo entrega al servicio y comprueba que se guarde con extensión `.png` y el mismo contenido.
2. Entrega texto que no es una imagen y verifica que el servicio lo rechace con un error de validación.

Se pueden ejecutar con `./mvnw test`.

## Pruebas

`ProductoImageStorageTest` contiene pruebas unitarias del servicio:

- Crea una imagen PNG válida en memoria, la guarda en una carpeta temporal y verifica que el nombre tenga extensión `.png` y que el contenido guardado coincida.
- Envía bytes que no son una imagen y verifica que el servicio los rechace.

Para ejecutar las pruebas:

```bash
./mvnw test
```

## Situación frente al taller

Ya se pueden crear productos con imagen, editar sus datos conservando la imagen cuando no se selecciona otra, y eliminar productos desde sus cards. La página principal muestra los productos en **cards**, no en una tabla como pide el taller. Todavía falta implementar una pantalla de consulta de detalle por ID y completar las pruebas manuales de todas las operaciones CRUD y persistencia después de reiniciar.

## Diseño de la página de inicio

- El icono hexadecimal verde de **Spring Boot** se reutiliza como logo junto a SpringStore.
- El tema claro conserva la paleta original. El botón de la barra superior alterna entre claro y oscuro; el oscuro usa fondos verde profundo y acentos verde neón.
- `theme-toggle.js` lee y guarda la preferencia en `localStorage`, para mantener el último tema elegido en ese navegador. Las reglas visuales de los dos temas están en `inicio.css`.
- El encabezado representa Spring Boot, Java y MySQL en tarjetas flotantes de estilo 3D. `hero-parallax.js` desplaza levemente las tarjetas según el movimiento del puntero, y `inicio.css` crea las órbitas, sombras, profundidad y animación. Si el sistema tiene activada la opción de reducir movimiento, las animaciones se minimizan.

## JPA: usar operaciones ya preparadas

Como `ProductoRepository` extiende `JpaRepository<Producto, Integer>`, Spring Data JPA ya ofrece operaciones comunes y Hibernate genera las consultas SQL correspondientes. No es necesario escribir `SELECT`, `INSERT`, `UPDATE` o `DELETE` a mano para el CRUD normal:

| Método | Para qué se usa |
|---|---|
| `findAll()` | Consultar y mostrar el catálogo completo. |
| `findById(id)` | Encontrar un producto antes de editarlo o eliminarlo. |
| `save(producto)` | Registrar un producto o guardar sus cambios. |
| `delete(producto)` | Eliminar el producto que previamente se buscó. |

En el borrado, primero se recupera el producto con `findById`. Después `delete(producto)` elimina el registro de la base de datos, y `imageStorage.delete(producto.getImagen())` elimina por separado el archivo local asociado. La base de datos y los archivos son almacenamientos distintos.

## Backup local del proyecto

Se creó una copia comprimida del proyecto en la carpeta `Backup/`, con el nombre `Parcial-20260929-143915.zip`. Incluye el código y los recursos locales del proyecto, incluidas las imágenes de `uploads/productos/`; excluye `.git`, `target`, `.idea`, `.vscode` y la propia carpeta `Backup` para evitar incluir el archivo dentro de sí mismo. La copia local está excluida de Git.

## Vocabulario para la sustentación

- **Vista:** página HTML que presenta la información.
- **Modelo:** objeto Java que representa un producto.
- **Controlador:** conecta las solicitudes del navegador con el modelo, repositorio y vistas.
- **Repositorio:** capa que consulta y guarda en MySQL.
- **Servicio:** componente que contiene lógica específica, aquí validación y almacenamiento de imágenes.
- **MultipartFile:** representación de Spring para un archivo enviado por un formulario.
- **Redirect:** instrucción al navegador para hacer una nueva solicitud a otra ruta.
