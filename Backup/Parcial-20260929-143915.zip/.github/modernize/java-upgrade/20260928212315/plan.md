ing# Upgrade Plan: Parcial (20260928212315)

- **Generated**: 2026-09-28 16:24:51 -05
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

> Version control is unavailable in this workspace; upgrade changes will remain uncommitted.

## Available Tools

**JDKs**
- JDK 21.0.12.1: /usr/lib/jvm/java-21-openjdk-amd64/bin (current project JDK; baseline)
- JDK 25.0.2: /home/rod-mint/.jdk/jdk-25.0.2/bin (target runtime)

**Build Tools**
- Maven Wrapper 3.9.16: project `mvnw` (used for all build and test commands)

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260928212315
- Run tests before and after the upgrade: true
- Execution mode: auto-execution

## Upgrade Goals

- Upgrade the Java runtime/compiler target from 21 to 25 (latest LTS as of 2026-09-28).

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| ---------------------- | ------- | ---------------------- | ---------------- |
| Java | 21 | 25 | User requested; project target property must match the selected LTS runtime. |
| Spring Boot | 4.1.1 | 4.1.1 | No upgrade requested; validate compatibility by compiling and testing on Java 25. |
| Maven Wrapper | 3.9.16 | 3.9.16 | Already adequate; no build-tool change needed. |
| Spring Boot Maven plugin | Spring Boot 4.1.1 managed | Current | Managed by the Spring Boot parent; validate under Java 25. |

## Derived Upgrades

- Set the Maven `java.version` property to 25 so compilation and runtime target the requested LTS.
- No Maven wrapper or Spring Boot upgrade is indicated by the discovered configuration. JDK 25 is already installed.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | `java.version` property | 21 | upgrade | 25 | Set compiler target to requested Java LTS. |

### Source Code Changes

No source changes identified. Source scan found no JDK-internal imports, reflection access to JDK internals, or Java-version-specific APIs requiring modification.

### Configuration Changes

No runtime configuration changes identified.

### CI/CD Changes

No CI/CD files or hardcoded Java-version references found. Only `pom.xml` contains a Java-version setting.

### Risks & Warnings

- **Runtime compatibility is not established by configuration alone**: Spring Boot 4.1.1 and project dependencies must build and tests must pass on JDK 25. **Mitigation**: run clean test compilation and the full test suite with JDK 25; fix any failures before completion.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Confirm the target JDK and wrapper are available before building.
  - **Changes to Make**: None; JDK 25 and the Maven wrapper are already present.
  - **Verification**: List installed JDKs; expected JDK 25 available at `/home/rod-mint/.jdk/jdk-25.0.2/bin`.

- Step 2: Setup Baseline
  - **Rationale**: Record current Java 21 compilation and test status for comparison.
  - **Changes to Make**: None.
  - **Verification**: `./mvnw clean compile test-compile -q && ./mvnw clean test -q` using JDK 21; expected successful compile and tests.

- Step 3: Upgrade Java Target
  - **Rationale**: Apply the user-requested Java 25 LTS target.
  - **Changes to Make**: Apply the `pom.xml` change in Impact Analysis > Dependency Changes.
  - **Verification**: `./mvnw clean test-compile -q` using JDK 25; expected production and test compilation to succeed.

- Step 4: CVE Validation & Fix
  - **Rationale**: Check resolved direct Java dependencies for known vulnerabilities after the target change.
  - **Changes to Make**: Upgrade only dependencies with reported fixes; update the relevant managed version if required.
  - **Verification**: Scan direct dependencies; if any are changed, rerun clean test compilation and rescan to confirm resolution.

- Step 5: Final Validation
  - **Rationale**: Confirm all requested goals and the full test suite on Java 25.
  - **Changes to Make**: Resolve any Java 25 compatibility failures; no unrelated changes.
  - **Verification**: `./mvnw clean test-compile -q && ./mvnw clean test -q` using JDK 25; expected successful compilation and 100% tests passing (or at least baseline pass rate).
